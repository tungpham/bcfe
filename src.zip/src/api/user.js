
import Axios from 'axios';

const SPEC_API_PATH = process.env.PROJECT_API + 'contractors/';

export default {
    upload: (files) => {

    }
}