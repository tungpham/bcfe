
export const SPECS_LOADED = 'SPECS_LOADED';
export const SPEC_LOADED = 'SPEC_LOADED';
export const SPEC_SELECTED = 'SPEC_SELECTED';
export const SPEC_UPDATED = 'SPEC_UPDATED';
export const SPEC_DELETED = 'SPEC_DELETED';
export const SPEC_CREATED = 'SPEC_CREATED';
export const SPEC_SET_PAGEINFO = 'SPEC_SET_PAGEINFO';

