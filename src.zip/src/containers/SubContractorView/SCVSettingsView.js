import React from 'react';

class SCVSettingsView extends React.Component {
	constructor(props) {
		super(props);
	}

	render() {
		return (
			<div>
				Settings
			</div>
		);
	}
}

export default SCVSettingsView;