import React, { Component } from 'react';

class HomeView extends Component {
	render() {
		return (
			<div>
				Welcome Home
			</div>
		);
	}
}

export default HomeView;